package com.greenloop.servlet;

import com.greenloop.dao.ProductDAO;
import com.greenloop.model.Products;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/vendor/products")
public class VendorProductServlet extends HttpServlet {
    private ProductDAO productDao;

    @Override
    public void init() {
        productDao = new ProductDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int vendorId = Integer.parseInt(request.getParameter("vendorId"));
        
        try {
            List<Products> products = productDao.getProductsByVendor(vendorId);
            request.setAttribute("products", products);
            request.getRequestDispatcher("/vendorProducts.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int vendorId = Integer.parseInt(request.getParameter("vendorId"));
        String productName = request.getParameter("productName");
        String description = request.getParameter("description");
        double price = Double.parseDouble(request.getParameter("price"));
        int stockQuantity = Integer.parseInt(request.getParameter("stockQuantity"));
        String category = request.getParameter("category");
        String imageUrl = request.getParameter("imageUrl");
        String sustainabilityCertifications = request.getParameter("sustainabilityCertifications");
        String sustainabilityMetrics = request.getParameter("sustainabilityMetrics");

        Products product = new Products();
        product.setVendorId(vendorId);
        product.setProductName(productName);
        product.setDescription(description);
        product.setPrice(price);
        product.setStockQuantity(stockQuantity);
        product.setCategory(category);
        product.setImageUrl(imageUrl);
        product.setSustainabilityCertifications(sustainabilityCertifications);
        product.setSustainabilityMetrics(sustainabilityMetrics);

        boolean success = productDao.addProduct(product);

        if (success) {
            response.sendRedirect(request.getContextPath() + "/vendor/products?vendorId=" + vendorId);
        } else {
            request.setAttribute("errorMessage", "Failed to add product. Please try again.");
            request.getRequestDispatcher("/vendorProducts.jsp").forward(request, response);
        }
    }
}
